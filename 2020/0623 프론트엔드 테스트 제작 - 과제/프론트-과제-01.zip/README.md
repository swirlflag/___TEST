# Plusx Frontend Developer Recruitment

플러스엑스 프론트엔드 면접 전 과제에 오신 것을 환영합니다!

안녕하세요! Plus X 프론트엔드 개발자 직군에 지원해 주셔서 감사합니다.
XXX 님이 보내주신 서류는 잘 보았습니다. 곧 있을 면접에 앞서 면접 전 과제를 준비해 드렸습니다.

## 과제 설명

이 과제는 pinterest에 있는 일부 간단한 웹 디자인을 차용해 텍스트와 사진을 더미로 변경해 출제하였습니다.
이 페이지를 수정해 적절하고 재미있는 인터렉션이 포함된 페이지로 만드는 것이 과제 내용의 전부입니다.
모바일 버전 및 반응형에 대한 준비는 하지 않으셔도 되며, 과제 확인 환경은 chrome, safari 두 브라우저로만 진행하겠습니다.

과제 자유도에 대한 부연 설명으로 몇 가지 예시를 알려드립니다.

- 원하는 인터랙션을 더 유리하게 구현하기 위해 HTML, CSS의 일체 모든 코드를 추가,삭제,변경 하셔도 "됩니다".
- 디자인이 마음에 들지 않아 이미지,색,텍스트,폰트,레이아웃 등 모든 디자인적 요소를 자유롭게 추가,삭제,교체 하셔도 "됩니다".
- 사용하시는 라이브러리가 있다면 추가하셔도 됩니다. 또한 필요하시면 폴더 구조 또한 변경하셔도 "됩니다".
- 지정된 화면이외에 추가 영역을 새롭게 더 개발하셔도 "됩니다".

요약 드리자면, 모든 파일의 모든 부분을 자유롭게 수정하셔도 됩니다.

## 제출 및 기한

제출 기한은 면접 직전까지이니 일찍 제출하셔도 좋고, 면접 시작 직전까지 업데이트해주셔도 됩니다.
제출 시간에 따른 기술적인 점수 변동은 없습니다.
하단의 제출 방법에 따른 pull request버전으로 검토합니다. 추가적인 제출을 하실 경우 다시 진행해 주시면 해당 버전으로 확인하겠습니다.
필요에 의해 이전 커밋의 기록을 같이 어필하실 경우, 함께 검토하겠습니다.

면접 시 제작해 주신 화면에 대해 간단한 설명을 부탁드릴 예정입니다.
기술적으로 어떻게 구현했는가, 혹은 화면상에서 왜 이런 인터랙션을 넣었는가와 같이 자유롭게 준비해 주세요.

> git 사용법(sourceTree도 괜찮습니다)은 [여기](https://git-scm.com/book/ko/v2), pull request 제출법은 [여기](https://help.github.com/en/github/collaborating-with-issues-and-pull-requests/creating-a-pull-request)를 참고해주세요.
> 작업하실 컴퓨터에 [git](https://git-scm.com)이 설치되었다고 가정합니다.

Terminal을 키셔서 작업하기 원하는 디렉토리로 이동 후 아래의 절차를 따라주시면 큰 문제 없이 동작할겁니다 :)

### 설치 및 시작
```
$ git --version
git version 2.23.0
# 버전이 맞을 필요는 없습니다. sourceTree와 같은 GUI 툴을 쓰는건 자유입니다
$ git clone https://github.com/@@@@@@@
$ cd Frontend-Assignment-00000
$ git checkout -b develop
$ git branch
  master
* develop
```

### 제출
```
$ git commit -am 'finished assignment!'
$ git push origin develop
```
다시 이 페이지로 돌아와서 compare & pull request 버튼을 통해 pull request를 제출하시면 됩니다.

모든 설명이 끝났습니다. 좋은 결과 바랍니다!